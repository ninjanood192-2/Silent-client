/*
 * Copyright 2026 Lambda
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.lambda.util.extension

import net.minecraft.util.math.Box
import net.minecraft.util.math.Vec3d

val Box.min get() = Vec3d(minX, minY, minZ)
val Box.max get() = Vec3d(maxX, maxY, maxZ)

fun Box.shrinkByEpsilon(): Box = expand(-1e-7)

operator fun Box.contains(boundingBox: Box) = this.intersects(boundingBox)
operator fun DoubleArray.component6() = this[5]
