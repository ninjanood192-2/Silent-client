/*
 * Copyright 2026 Lambda
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.lambda.util.collections

import kotlin.reflect.KProperty

/**
 * This structure lazily evaluates the [getter] lambda and stores its result in its [cache].
 *
 * Example:
 * ```kt
 * val String.sha256: String by cacheable { it.hashString("SHA-256") }
 *
 * val hash1 = "aa".sha256 // lazily evaluated and stored
 * val hash2 = "aa".sha256 // value fetched from the cache
 * val hash3 = "bb.sha256 // lazily evaluated and stored
 * ```
 */
class Cacheable<K, V> private constructor(private val getter: (K) -> V) {
    private val cache = mutableMapOf<K, V>()

    operator fun getValue(thisRef: K, property: KProperty<*>) =
        cache.getOrPut(thisRef) { getter(thisRef) }

    companion object {
        fun <K, V> cacheable(getter: (K) -> V) = Cacheable(getter)
    }
}
