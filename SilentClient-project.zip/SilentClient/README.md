# Silent Client

Client-side Fabric mod scaffold for Minecraft **1.21.11**.

## Included
- Minimal on-screen status HUD.
- Fabric build configuration using official Mojang mappings.
- GitHub Actions workflow that builds the mod and uploads the JAR.

## Not included
This is a fair-play project. It does not include KillAura, automated attacks, or combat cheats.
A local-only cosmetic dummy-player feature is a possible future addition; it is not implemented in this starter scaffold.

## Build
Requires JDK 21 and Gradle 8.14.

```bash
gradle build
```

The remapped mod JAR will be in `build/libs/`.

## Install
Copy the built JAR into the `mods` folder of a Fabric 1.21.11 client with Fabric API installed.
