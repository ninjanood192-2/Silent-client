package com.silentclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

public final class SilentClient implements ClientModInitializer {
    public static final String MOD_ID = "silentclient";

    @Override
    public void onInitializeClient() {
        Identifier hudId = Identifier.fromNamespaceAndPath(MOD_ID, "status_hud");
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                hudId,
                (graphics, deltaTracker) -> graphics.drawString(
                        Minecraft.getInstance().font,
                        "Silent Client  |  HUD enabled",
                        8,
                        8,
                        0xFFFFFFFF,
                        true
                )
        );
    }
}
